*********
README
*********


*********
Directions:

1.
Move the infotaker folder to your Desktop

2.
Navigate into the infotaker folder(the folder you’re in right now) 

3.
Double-click the infotaker.command script

*********


*********
About:

Infotaker is a project that I worked on to learn a bit about python
and its applications.

*********
