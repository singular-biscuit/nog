import time
import os

print""
time.sleep(.5)
print"*********"
time.sleep(.5)
print"infotaker"
time.sleep(.5)
print"*********"
time.sleep(.5)
print""
time.sleep(.5)
print""
print""
print"What Is Your Name?"
name=raw_input()
time.sleep(.3)
print""
print "Is This Correct?"
print name
time.sleep(.3)
print""
response1=raw_input("y/n")
print""
if response1 == "y":
	print"Your Name = "+name
	time.sleep(.3)
elif response1 == "n":
	print"What Is Your Name?"
	name=raw_input()
	time.sleep(.3)
	print""
	print "Your Name = "+name
print""
print"What Is Your Age?"
age=raw_input()
time.sleep(.3)
print""
print"Your Age Is "+age+"?"
print""
response2=raw_input("y/n")
print""
if response2 == "y":
	time.sleep(.5)
	print"Your Age Is "+age
elif response2 == "n":
	print"What Is Your Age?"
	age=raw_input()
	time.sleep(.5)
	print""
	print "You Are "+age+" Years Old"
print""
os.mkdir("/Users/student/Desktop/"+name)
info_file = open("/Users/student/Desktop/"+name+"/"+name, 'w')
info_file.write(name+"\n"+age)
time.sleep(1)
print""
time.sleep(1)
print"Your Info File Is on Your Desktop"
time.sleep(1)
print""
time.sleep(1)
print""
print"*********"
time.sleep(1)
print"*********"
